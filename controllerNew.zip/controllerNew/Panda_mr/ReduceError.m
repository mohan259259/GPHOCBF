function x = ReduceError(x, i)

if x > -1/(10^i) && x < 1/(10^i)
    x = 0;
else
end
end