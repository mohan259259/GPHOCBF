function [p, J] = Panda_FK_and_Jacobian(q)
% PANDA_FK_AND_JACOBIAN Panda机器人的位置计算与Jacobian计算
% Input q 关节列表
% Output p机器人末端位置 J机器人Jacobian







end

